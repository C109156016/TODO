// ***********************************************
// This example defaults.js shows you how to
// customize the internal behavior of Cypress.
//
// The defaults.js file is a great place to
// override defaults used throughout all tests.
//
// ***********************************************
//
// Cypress.Server.defaults({
//   delay: 500,
//   whitelist: function(xhr){}
// })

// Cypress.Cookies.defaults({
//   whitelist: ["session_id", "remember_token"]
// })
